# -*- coding: utf-8 -*-
#__author__ = 'zj'
#__Date__ = 19-05-13 上午10:48


import os, sys, yaml
from datetime import datetime
from cmd import ExecCmd
sys.path.append("/data/Log-cleanup")


class Run(object):
	def read_data(self):
		with open("/data/Log-cleanup/config/config.yaml") as fr:
			data = yaml.safe_load(fr)
		return data.items()

	def logs(self, Msg):
		logs_file = '/data/Log-cleanup/logs/{}.{}'.format(datetime.now().strftime("%Y_%m_%d_%H"), "logs")
		f = open(logs_file, 'a+')
		f.write(Msg)
		f.close()

	def log_item(self):
		data = self.read_data()
		for num in range(0, len(data)):
			try:
				ExecCmd(data[num][1]['file_dir'],data[num][1]['expire_time'],data[num][1]['file_size'],data[num][1]['file_re'],data[num][1]['file_tmp']).exec_find()
			except Exception as e:
				print("获取状态失败, 错误原因：{0}".format(e))


if __name__ == "__main__":
	test=Run()
	test.log_item()
	# print test.read_data()
