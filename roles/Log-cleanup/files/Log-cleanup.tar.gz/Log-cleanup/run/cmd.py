# -*- coding: utf-8 -*-
#__author__ = 'zj'
#__Date__ = 18-11-13 下午5:34

import yaml, os, re, sys, time, datetime, logging, shutil, tarfile
sys.path.append("/data/Log-cleanup")


class ExecCmd(object):
    def __init__(self, file_dir=None, expire_time=None, file_size=None, file_re=None, file_tmp=None):
        if file_dir == None:
            print(u"日志目录不能为空")
        else:
            self.file_dir = file_dir
        if expire_time == None:
            print(u"日志过期时间不能为空")
        else:
            self.expire_time = expire_time
        if file_size == None:
            print(u"日志文件大小不能为空")
        else:
            self.file_size = file_size
        if file_re == None:
            print(u"日志正则不能为空")
        else:
            self.file_re = file_re
        if file_tmp == None:
            self.file_tmp = '/data/Log-cleanup/tmp'
        else:
            self.file_tmp = file_tmp
        self.recycle()

    def recycle(self):
        list_file = os.listdir(self.file_tmp)
        today = datetime.datetime.now()
        n_days = datetime.timedelta(days=int(1))
        n_days_agos = today - n_days
        n_days_agos_timestamps = time.mktime(n_days_agos.timetuple())
        for date_file in list_file:
            abs_file = os.path.join(self.file_tmp,date_file)
            file_timestamp = os.path.getmtime(abs_file)
            if float(file_timestamp) <= float(n_days_agos_timestamps):
                if os.path.isfile(abs_file):
                    os.remove(abs_file)
                    self.logs('删除文件：[%s]成功' % abs_file)


    def logs(self,Msg):
        logs_file = '/data/Log-cleanup/logs/{}.{}'.format(datetime.datetime.now().strftime("%Y_%m_%d_%H"), "logs")
        f = open(logs_file, 'a+')
        f.write(Msg)
        f.close()

    def exec_find(self):
        all_file = os.listdir(self.file_dir)
        reg_str = ('|'.join(self.file_re))
        reg_file_list = []

        for reg_file in all_file:
            if re.search(reg_str,reg_file):
                reg_file_list.append(reg_file)


        today = datetime.datetime.now()
        n_days = datetime.timedelta(days=int(self.expire_time))
        n_days_agos = today - n_days
        n_days_agos_timestamps = time.mktime(n_days_agos.timetuple())

        file_group = os.walk(self.file_dir)
        for path,dir_list,file_list in file_group:  
            for file_name in file_list:  
                abs_file = os.path.join(path,file_name)
                file_timestamp = os.path.getmtime(abs_file)
                tmp_size = int(((float(os.path.getsize(abs_file)) / 1024) / 1024) / 1024 )
                if tmp_size >= self.file_size:
                    self.logs('文件大于1G：[%s]' % abs_file)
                    if os.path.isfile(abs_file):
                        f = open(abs_file, 'a')
                        f.seek(0)
                        f.truncate()
                        f.close()
                else:
                    if float(file_timestamp) <= float(n_days_agos_timestamps):
                        self.logs('过期匹配到文件：%s\n' % abs_file)
                        if os.path.isfile(abs_file):
                            self.exec_tar(abs_file)



    def exec_tar(self, file):
        (filepath, filename) = os.path.split(file)   
        fileName = '/data/Log-cleanup/tmp/{}.tar.gz'.format(filename)
        tar = tarfile.open(fileName, 'w:gz')
        tar.add(file)
        tar.close()
        os.remove(file)
        self.logs('压缩文件：%s 成功\n' % file)

if __name__ == "__main__":
    test = ExecCmd('/data/tomcat/tomcat-8080/logs','1','1',['.log$','.out$'],'../tmp')
    test.exec_find()



